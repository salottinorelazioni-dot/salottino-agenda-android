# Salottino Agenda Android

Wrapper Android di **Salottino Agenda**.

## Come funziona

L'app Android carica sempre:

`https://salottino-agenda.vercel.app/`

Quindi gli aggiornamenti pubblicati sulla web app diventano disponibili anche nell'app Android senza dover ricreare l'APK, salvo modifiche specifiche alla parte Android.

L'app mantiene cookie e memoria locale del WebView, mentre all'avvio forza il ricaricamento delle risorse web e chiede al Service Worker di verificare eventuali aggiornamenti.

## APK automatico con GitHub Actions

Ad ogni push sul branch `main`, il workflow:

`.github/workflows/android-apk.yml`

compila un APK di debug e lo pubblica come artifact denominato:

`Salottino-Agenda-APK`

Per scaricarlo:
1. Apri la scheda **Actions** del repository.
2. Apri l'ultima esecuzione **Build Android APK**.
3. Scorri fino a **Artifacts**.
4. Scarica `Salottino-Agenda-APK`.

## Pacchetto Android

`it.salottino.agenda`

La build debug usa automaticamente il suffisso `.debug`.

## Nota

Questa prima build è pensata per installazione diretta/sideload e test interni. Per Google Play conviene aggiungere successivamente una chiave di firma release e generare un AAB firmato.
